Entrega do exercicio da unidade 2 de DINT.

==> Reestructuracion do proxecto inicial en novas carpetas e subcarpetas para unha mellor organización
==> Actualicei funcionalidades do formulario de exemplo (Os botóns permitenche sair da aplicación e ver a nova ventana modal)
==> Creación da ventana modal que pedía o excercicio:
	- Funcionalidades de seleccion
	- Limitación en inputs numericos, fechas...
	- Engadido deseño 
	- Acceso as ventanas modais a partir dos botons de inicio e do menú principal
==> Ventana de notificacion de usuario da reserva realizada.


Espero que non existan erros de compilación. No meu ordenador funciona correctamente, se existe algún problema faimo saber


Un saudo e bo día/tarde/noite 😃😃😃
